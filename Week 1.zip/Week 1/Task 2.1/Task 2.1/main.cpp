#include <iostream>
using namespace std;

class BouncyNumber {
    int num;

public:
    void getInput() {
        cout << "Enter a positive integer: ";
        cin >> num;
    }

    void checkBouncy() {
        if (num < 100) {
            cout << num << " Invalid input must require atleast 3 number ex:123 " << endl;
            void getInput();
            return;
        }

        bool Increase = false, Decrease = false;
        int numCopy = num;
        int lastDigit = numCopy % 10;
        numCopy /= 10;

        while (numCopy > 0) {
            int currentDigit = numCopy % 10;

            if (currentDigit < lastDigit) Increase = true;
            if (currentDigit > lastDigit) Decrease = true;

            lastDigit = currentDigit;
            numCopy /= 10;

            if (Increase && Decrease) {
                cout << num << "Bouncy number." << endl;
                return;
            }
        }

        cout << num << "Not a bouncy number." << endl;
    }
};

int main() {
    BouncyNumber BN;
    BN.getInput();
    BN.checkBouncy();
    return 0;
}

