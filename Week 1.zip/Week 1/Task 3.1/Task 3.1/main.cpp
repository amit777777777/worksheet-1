#include <iostream>
using namespace std;

class Cinema {
private:
    char seats[5][5];
    int row, col;
    char choice;
    
public:
        Cinema() {
        for (int i = 0; i < 5; i++) {
            for (int j = 0; j < 5; j++) {
                seats[i][j] = 'O';
            }
        }
    }

    void displaySeats() {
        cout << "Seating Arrangement:" << endl;
        for (int i = 0; i < 5; i++) {
            for (int j = 0; j < 5; j++) {
                cout << seats[i][j] << " ";
            }
            cout << endl;
        }
    }

    void bookSeat() {
        cout << "Enter row between 1 and 5 ";
        cin >> row;
        cout << "Enter column between 1 and 5 ";
        cin >> col;

        if (row < 1 || row > 5 || col < 1 || col > 5) {
            cout << "Invalid seat selection! Please enter row and column between 1 and 5." << endl;
            return;
        }

        if (seats[row - 1][col - 1] == 'X') {
            cout << "Please choose another seat this is booked" << endl;
        } else {
            seats[row - 1][col - 1] = 'X';
            cout << "Seat has been booked successfully" << endl;
        }
    }

    void bookingLoop() {
        do {
            displaySeats();
            bookSeat(); //
            cout << "Do you want to book another seat? press [y or n] ";
            cin >> choice;
        } while (choice == 'y' || choice == 'n');
    }
};

int main() {
    Cinema cinema;
    cinema.bookingLoop();
    cinema.displaySeats();
    return 0;
}

