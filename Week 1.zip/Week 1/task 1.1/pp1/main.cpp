#include <iostream>
#include <limits>

using namespace std;

class convert {
    float ip, op;
    int ch;

public:
    void showmenu() {
        cout << "Choose Conversion" << endl;
        cout << "1. Fahrenheit to Celsius" << endl;
        cout << "2. Celsius to Fahrenheit" << endl;

        while (!(cin >> ch) || (ch != 1 && ch != 2)) {
            cout << "Invalid choice! Please enter 1 or 2: ";
            cin.clear();
            cin.ignore(numeric_limits<streamsize>::max(), '\n');
        }
    }

    void get_input() {
        cout << "Enter the temperature value: ";
        while (!(cin >> ip)) {
            cout << "Invalid input! Please enter numeric temperature value: ";
            cin.clear();
            cin.ignore(numeric_limits<streamsize>::max(), '\n');
        }
    }

    void convert_to_C() {
        op = (ip - 32) / 1.8;
    }

    void convert_to_F() {
        op = (ip * 1.8) + 32;
    }

    void conversion() {
        if (ch == 1) {
            convert_to_C();
        } else {
            convert_to_F();
        }
    }

    void display() {
        if (ch == 1)
            cout << "Result = " << op << " °C" << endl;
        else
            cout << "Result = " << op << " °F" << endl;
    }
};

int main() {
    convert c1;
    c1.showmenu();
    c1.get_input();
    c1.conversion();
    c1.display();

    return 0;
}


