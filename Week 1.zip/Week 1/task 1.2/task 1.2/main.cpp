#include <iostream>
using namespace std;
class Game
{
    int Ip,Rn,Ch;
    
public:
    
    void Game_option()
    {
        cout<<"Choose the level"<<endl;
        cout<<"1. Difficulty_level_Easy"<<endl;
        cout<<"2. Difficulty_level_Medium"<<endl;
        cout<<"3. Difficulty_level_Hard"<<endl;
        cout<<"choose between 1, 2 and 3"<<endl;
        cin>>Ch;
    }
    
    void Easy_difficulty()
    {
        Rn=rand() % 8 + 1;
        cout<<"Choose the number between 1 and 10"<<endl;
        cin>>Ip;
    }
    
    void Medium_difficulty()
    {
        Rn=rand() % 30 + 1;
        cout<<"Choose the number between 1 and 20"<<endl;
        cin>>Ip;
    }
    
    void Hard_difficulty()
    {
        Rn=rand() % 50 + 1;
        cout<<"Choose the number between 1 and 50"<<endl;
        cin>>Ip;
    }
    
    void level()
    {
        if( Ch==1){
            Easy_difficulty();
        }
        
        else if (Ch==2){
            Medium_difficulty();
        }
        else if (Ch==3){
            Hard_difficulty();
        }
        else{
            cout<<"Invalid input"<<endl;
            void Game_option();
        }
    }
    
    void result()
    {
        if (Rn<Ip){
            cout<<"Too high Better luck next time."<<endl;
            cout<<"The random number was "<<Rn <<endl;
            void Game_option();
        }
        else if (Rn>Ip){
            cout<<"Too low Better luck next time."<<endl;
            cout<<"The random number was "<<Rn <<endl;
            void Game_option();
        }
        else{
            cout<<" Congratulations You are a Genius."<<endl;
            cout<<"The random number was "<<Rn <<endl;
        }
    }
};

int main()
{
    Game G1;
    G1.Game_option();
    G1.level();
    G1.result();
    
    return 0;
}
